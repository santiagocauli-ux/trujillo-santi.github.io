# Comment publier ton portfolio gratuitement (GitHub Pages)

Ce dossier contient ton site complet : `index.html`, `style.css`, `script.js` et le dossier `images/`.

## Étapes

1. **Crée un compte GitHub** (gratuit) : https://github.com/signup

2. **Crée un nouveau dépôt (repository)** :
   - Clique sur "New repository"
   - Nom suggéré : `portfolio` ou `ton-nom.github.io` (ce deuxième nom te donne une URL plus simple)
   - Laisse-le public
   - Ne coche aucune case d'initialisation (pas de README ici, on a déjà nos fichiers)

3. **Envoie les fichiers** :
   - Dans la page du dépôt, clique sur "uploading an existing file"
   - Glisse-dépose TOUT le contenu de ce dossier (index.html, style.css, script.js, et le dossier images/ complet)
   - Clique sur "Commit changes"

4. **Active GitHub Pages** :
   - Va dans l'onglet "Settings" du dépôt
   - Menu de gauche → "Pages"
   - Sous "Branch", choisis `main` et le dossier `/ (root)`
   - Clique "Save"

5. **Attends 1-2 minutes** — GitHub te donnera une URL du type :
   `https://ton-nom-utilisateur.github.io/portfolio/`

C'est gratuit, sans publicité, et sans limite de temps. Pour modifier le site plus tard, tu peux revenir ici et me demander les changements — je réécrirai les fichiers et tu n'auras qu'à les re-uploader (ou les remplacer directement sur GitHub).

## Structure du site

- **Portraits** (8) — pièces peintes centrées sur le visage
- **Personnages & Fantaisie** (8) — mondes oniriques, personnages stylisés
- **Animaux** (2)
- **Pixel Art** (2)

Chaque image s'agrandit au clic (lightbox). La navigation en haut défile vers chaque section.
